# from langchain.chat_models import ChatOpenAI
from langchain_community.chat_models import ChatOpenAI
from langchain.schema import HumanMessage

llm = ChatOpenAI(
    openai_api_key="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",
    openai_api_base="https://api.groq.com/openai/v1",
    model="llama3-8b-8192"
)

response = llm([
    HumanMessage(content="Explain AI in one line.")
])
print(response.content)
