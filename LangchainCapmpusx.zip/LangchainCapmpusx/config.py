# config.py
import os
from dotenv import load_dotenv

load_dotenv()  # load variables from .env into environment

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_API_BASE = os.getenv("OPENAI_API_BASE")