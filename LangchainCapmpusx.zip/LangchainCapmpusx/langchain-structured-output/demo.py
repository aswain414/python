import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from config import OPENAI_API_KEY, OPENAI_API_BASE

from langchain_openai import ChatOpenAI
from pydantic import BaseModel

# 1. Define structured output schema
class SayariSchema(BaseModel):
    topic: str
    sayari: str

# 2. Create LLM model
llm = ChatOpenAI(
    openai_api_key=OPENAI_API_KEY,
    openai_api_base=OPENAI_API_BASE,
    model="llama3-8b-8192"
)

# 3. Bind the model with the schema
structured_llm = llm.with_structured_output(SayariSchema)

# 4. Invoke with input instruction
result = structured_llm.invoke("Write a Hindi sayari about 'mohabbat'.")

# 5. Print structured result
print("result",result)  # SayariSchema object
print("topic:",result.topic)   # mohabbat
print("sayari:",result.sayari)  # the actual sayari
print("\ndosti sayari example:\n")
print(llm.invoke("Write a Hindi sayari about 'dosti'."))  # another example
