import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from config import OPENAI_API_KEY, OPENAI_API_BASE

from langchain_openai import ChatOpenAI
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser

model = ChatOpenAI(
    openai_api_key=OPENAI_API_KEY,
    openai_api_base=OPENAI_API_BASE,
    model="llama3-8b-8192")
	
prompts1= PromptTemplate(
			template="Write a detailed report about this topic {topic}",
			input_variables=["topic"]
)
prompts2= PromptTemplate(
			template="Generate a summary point wise of the report on {text}",
			input_variables=["text"]
)

parser=StrOutputParser()
chain= prompts1 | model | parser | prompts2 | model | parser
result= chain.invoke({'topic':'Cricket'})
print(result)
print(chain.get_graph().print_ascii())