import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from config import OPENAI_API_KEY, OPENAI_API_BASE

from langchain_openai import ChatOpenAI
from langchain_core.prompts import PromptTemplate

model = ChatOpenAI(
    openai_api_key=OPENAI_API_KEY,
    openai_api_base=OPENAI_API_BASE,
    model="llama3-8b-8192")

prompt_template=PromptTemplate(
    template="Write a beatuiful sayari on {topic} in hindi",
    input_variables=["topic"]
)
topic = input("Enter a topic: ")
chain=prompt_template | model
result= chain.invoke({'topic': topic})
print("AI: ", result.content)