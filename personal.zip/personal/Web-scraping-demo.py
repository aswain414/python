import pandas as pd
import requests
from bs4 import BeautifulSoup
headers={"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.14; rv:66.0) Gecko/20100101 Firefox/66.0"}
webpage=requests.get('https://www.w3schools.com/html/html_elements.asp',headers=headers).text
soup=BeautifulSoup(webpage)
data=soup.find_all('h2')

for i in soup.find_all('h2'):
  print(i.text.strip())