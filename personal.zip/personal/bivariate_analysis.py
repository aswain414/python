fruits = ["apple", "banana", "cherry"]
print("Loop start")
for x in fruits:
    print(x)
    if x=='banana':
    	break
print("Loop end")
# import pandas as pd
# import seaborn as sns
# import matplotlib.pyplot as plt

# Load datasets
# tips = sns.load_dataset('tips')

# 1. Scatterplot (Numerical - Numerical)
# sns.scatterplot(x=tips['total_bill'], y=tips['tip'], hue=tips['sex'], style=tips['smoker'], size=tips['size'])

# Show the plot
# plt.show()


# 2. Bar Plot (Numerical - Categorical)
# 3. Box Plot (Numerical - Categorical)
# 4. Distplot (Numerical - Categorical)
# 5. HeatMap (Categorical - Categorical)
# 6. ClusterMap (Categorical - Categorical)
# 7. Pairplot
# 8. Lineplot (Numerical - Numerical)
