#  41d4bd8de47221f21b2b3aee20af4b1d

import requests

url = "https://api.themoviedb.org/3/movie/changes?page=1"

headers = {
    "accept": "application/json",
    "Authorization": "Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI0MWQ0YmQ4ZGU0NzIyMWYyMWIyYjNhZWUyMGFmNGIxZCIsIm5iZiI6MTczOTI1MDMxNS45MDYsInN1YiI6IjY3YWFkYThiMTVjZjI5NjA2ZWIwOTc0OCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.Shn6zGZ-HchCypWoy_fnfmhuyyJ3k6_uY6YSz-OClhI"
}

response = requests.get(url, headers=headers)

print(response.text)