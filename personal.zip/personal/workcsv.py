import pandas as pd

# Open a csv file from local systems
# import pandas as pd
# df=pd.read_csv('placement.csv')
# print(df)

# Opening a CSV file from an URL
# import pandas as pd
# import requests 
# from io import StringIO 
# url="https://raw.githubusercontent.com/cs109/2014_data/master/countries.csv" 
# headers={"User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.14; rv:66.0) Gecko/20100101 Firefox/66.0"}
# req= requests.get(url, headers=headers) 
# data =StringIO(req.text) 
# df=pd.read_csv(data)
# print(df) 

# in read_csv by default sep=',' means separated by comma
# import pandas as pd
# df=pd.read_csv('files/students.tsv',sep='\t',name=['ID','NAME','AGE','GRADE','EMAIL'])
# df=pd.read_csv('files/students.tsv',sep='\t')
# print(df)

# 5. index_col parameter
# remove the default index and cgpa is the index
# df=pd.read_csv('files/placement.csv',index_col='cgpa')
# print(df)

# 6.Header paramter 
# df=pd.read_csv('test.csv',header=1)

# 7.use_cols parameter
# suppose i want only 2 column then i will pass in a list column names
# df=pd.read_csv('files/placement.csv',usecols=['cgpa','placement'])
# print(df)

#8. Squeeze parameters
# pd.read_csv('files/placement.csv',squeeze=True)

# 9.skipprows/nrows Parameter
# it skip the rows
#nrows: means total rows suppse i want 100 record then i will pass nrows=100
# df=pd.read_csv('files/placement.csv',skiprows=[0,1])
# print(df)

# 10. Encoding parameter
# df=pd.read_csv('files/placement.csv',encoding='latin-1')

# 11. Skip bad lines
# error_bad_lines menas suppose in your file thieir is 5 column in some rows it contain 6 column then error showing.
# so error_bad_lines=False means it did not get error
# pd.read_csv('Bx-books.csv',sep=';',encoding="latin-1",error_bad_lines=False)
 
# 12. dtypes parameter
# you can change the data type of column
# pd.read_csv('aug_train.csv',dtype={'target':int})

# 13. Handling Dates
# it convert to date format so that we can easily get month name or date related data
# pd.read_csv("IPL 2008-202.csv",parse_dates=['date'])

# 14. Convertors
# suppose i want to write sort name of teams like if Royal Challengers Banglore then show RCB

# def rename(name):
#     if name=="Royal Challengers Banglore"
#         return "RCB"
#     else:
#         return name

# pd.read_csv("IPL 2008-202.csv",converters={'team1':rename})

# 15. na_values parameter
# suppose i have some value like male/feamale but blank and '' like this i will them as nan
# pd.read_csv('abc.csv',na_values=['Male'])

# 16. Loading a huge dataset in chunks
# suppose i have huge data set then i will chunk (seperated) them to run perfectly
# if we use chunksize then we will find data as in for Loop
# dfs=pd.read_csv('abc.csv',chunksize=5000)
# for chunks in dfs:
#     print(chunk.shape)